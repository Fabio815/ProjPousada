package br.ifsc.pousada.modelos;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import br.ifsc.pousada.daopersistir.LeitorJson;

public class Pessoa {
	private static Long id = 0L;
	private String nome;
	private LocalDate dtNascimento;
	private String telefone;
	private String cpf;
	
	public Pessoa(String nome, LocalDate dtNascimento, String telefone, String cpf) {
		super();
		this.nome = nome;
		this.dtNascimento = dtNascimento;
		this.telefone = telefone;
		this.cpf = cpf;
	}
	
	public Pessoa() {
		
	}

	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public LocalDate getDtNascimento() {
		return dtNascimento;
	}
	
	public void setDtNascimento(LocalDate dtNascimento) {
		this.dtNascimento = dtNascimento;
	}
	
	public String getTelefone() {
		return telefone;
	}
	
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

    public static Long getId() {
		return id;
	}

	public static void setId(Long id) {
		Pessoa.id = id;
	}
}





