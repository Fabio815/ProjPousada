package br.ifsc.pousada.daopersistir;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import br.ifsc.pousada.modelos.Cliente;
import br.ifsc.pousada.modelos.Funcionario;
import br.ifsc.pousada.modelos.Quarto;
import br.ifsc.pousada.modelos.Reserva;

public class FazerReserva {
	private static final Scanner leitura = new Scanner(System.in);
	
	public static void cadastroReserva() {
		System.err.println("""
				[1] Listar Clientes
				[2] Cadastrar Reserva
				[3] Listar Quartos
				""");
		System.err.print("Opção: ");
		int opcao = leitura.nextInt();
		switch (opcao) {
			case 1:
				carregarDadosClientes();
				break;
			case 2:
				cadastrarReserva();
				break;
			case 3:
				ListarQuartos.listar();;
				break;
		}
	}
	
	private static void cadastrarReserva() {
		ObjectMapper objeto = new ObjectMapper();
		String CAMINHO_ARQUIVO = "C:\\Users\\fabio\\git\\repository\\Pousada\\reserva.json";
		System.err.println("Digite o cpf do Cliente: ");
		String cpf = leitura.nextLine();
		System.err.println("Número do quarto: ");
		int numeroQuarto = leitura.nextInt();
		Cliente cliente = Cliente.carregarCliente(cpf);
		Funcionario funcionario = Funcionario.carregarFuncionario();
		Quarto quarto = Quarto.carregarQuarto(numeroQuarto);
		
		try {
			objeto.registerModule(new JavaTimeModule());
			File arquivo = new File(CAMINHO_ARQUIVO);
			List<Reserva> reserva = null;

			
			
			if (arquivo.exists()) {
				CollectionType tipoLista = objeto.getTypeFactory()
					.constructCollectionType(List.class, Reserva.class);
				
				reserva = objeto.readValue(arquivo, tipoLista);
			} else {
				reserva = new ArrayList<>();
			}
			
			//final var json = objeto.writerWithDefaultPrettyPrinter().writeValueAsString(clientes); //transformanfo objeto em json
			objeto.writerWithDefaultPrettyPrinter().writeValue(arquivo, reserva);

			System.out.println("Cliente adicionado com sucesso!");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
	}

	public static void carregarDadosClientes() {
		ObjectMapper objeto = new ObjectMapper();
		try {
			objeto.registerModule(new JavaTimeModule());
			String json = LeitorJson.readJson("C:\\Users\\fabio\\git\\repository\\Pousada\\clientes.json");
			List<Cliente> clientes = objeto.readValue(json, new TypeReference<List<Cliente>>() {});
			int cont = 0;
			for(Cliente c : clientes) {
				System.err.println("Indice: [" + cont + "]");
				System.err.println("CPF: " + c.getCpf());
				System.err.println("Nome: " + c.getNome());
				System.err.println("Data Nascimento: " + c.getDtNascimento());
				System.err.println("Telefone: " + c.getTelefone());
				System.err.println("Email: " + c.getEmail());
				System.err.println("\n");
				cont++;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
